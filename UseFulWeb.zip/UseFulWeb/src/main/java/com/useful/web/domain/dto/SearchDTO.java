package com.useful.web.domain.dto;

public class SearchDTO {
	
}
