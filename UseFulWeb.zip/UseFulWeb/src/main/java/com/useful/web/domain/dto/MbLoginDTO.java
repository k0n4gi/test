package com.useful.web.domain.dto;

import com.useful.web.domain.vo.LottoResultVO;

public class MbLoginDTO extends LottoResultVO{

}
