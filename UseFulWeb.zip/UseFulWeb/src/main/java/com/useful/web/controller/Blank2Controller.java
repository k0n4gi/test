package com.useful.web.controller;

import java.text.DateFormat;
import java.util.Date;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.useful.web.utils.Client;
import com.useful.web.utils.HandlerFile;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Blank2Controller {

	private static final Logger logger = LoggerFactory.getLogger(Blank2Controller.class);

	/*
	 * @RequestMapping(value = "/blank2", method = RequestMethod.GET) public String
	 * page(Locale locale, Model model) { logger.info("blank2", locale); return
	 * "blank/blank2"; }
	 */

	@RequestMapping(value = "/blank2", method = RequestMethod.GET)
	public String page(Locale locale, Model model) {
		logger.info("blank2", locale);
		return "blank/blank2";
	}

	/*
	 * @RequestMapping(value = "/blank2/test", method = RequestMethod.POST) public
	 * String test(Locale locale, Model model, MultipartHttpServletRequest
	 * mtfRequest) { logger.info("blank2",locale); String src =
	 * mtfRequest.getParameter("src"); System.out.println("src value : " + src);
	 * MultipartFile mf = mtfRequest.getFile("file");
	 * 
	 * String path = "C:\\Users\\user\\Desktop\\java_img";
	 * 
	 * String originFileName = mf.getOriginalFilename(); // 원본 파일 명 long fileSize =
	 * mf.getSize(); // 파일 사이즈
	 * 
	 * System.out.println("originFileName : " + originFileName);
	 * System.out.println("fileSize : " + fileSize);
	 * 
	 * String safeFile = path + System.currentTimeMillis() + originFileName;
	 * 
	 * try { mf.transferTo(new File(safeFile));
	 * 
	 * } catch (IllegalStateException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } catch (IOException e) { // TODO Auto-generated catch
	 * block e.printStackTrace(); } return "blank/blank2"; }
	 */

	@RequestMapping(value = "/blank2/test", method = RequestMethod.POST)
	public void fileUpload(MultipartHttpServletRequest multipartRequest, HttpServletResponse response) {
		// 추가데이터 테스트
		System.err.println(multipartRequest.getParameter("temp"));
		String filePath = "C:/Users/user/Desktop/java_img";

		HandlerFile handlerFile = new HandlerFile(multipartRequest, filePath);

		Map<String, List<String>> fileNames = handlerFile.getUploadFileName();
		// 실제저장파일명과 원본파일명 DB저장처리

		// 클라이언트 객체
		System.err.println(fileNames.toString());
		String fileName = handlerFile.getFileFullPath();
		Client client = new Client(fileName);
		String result = client.getResult();
		String js;
		ServletOutputStream out;

		try {
			response.setContentType("text/html; charset=UTF-8");
			out = response.getOutputStream();

			if (result.equals("null") || result.equals("fail")) {
				js = "<script>history.back(); alert('Result : Error! Page Reload!');</script>";
			} else {
				js = "<script>alert('Result : " + result + "'); location.href='https://www.google.co.kr/search?q="
						+ result + "'</script>";
			}

			out.println(js);
			out.flush();

		} catch (Exception e) {
			e.printStackTrace();
		} // catch

	}// fileUpload
}
