package com.useful.web.domain.vo;

public class LottoResultVO {
	private int lt_code;
	private int lt_drw_no;
	private int lt_drwt_no_1;
	private int lt_drwt_no_2;
	private int lt_drwt_no_3;
	private int lt_drwt_no_4;
	private int lt_drwt_no_5;
	private int lt_drwt_no_6;
	private Long lt_tot_sell_amnt;
	private Long lt_first_win_amnt;
	private String lt_drw_date;

	public int getLt_code() {
		return lt_code;
	}

	public void setLt_code(int lt_code) {
		this.lt_code = lt_code;
	}

	public int getLt_drw_no() {
		return lt_drw_no;
	}

	public void setLt_drw_no(int lt_drw_no) {
		this.lt_drw_no = lt_drw_no;
	}
	public int getLt_drwt_no_1() {
		return lt_drwt_no_1;
	}

	public void setLt_drwt_no_1(int lt_drwt_no_1) {
		this.lt_drwt_no_1 = lt_drwt_no_1;
	}

	public int getLt_drwt_no_2() {
		return lt_drwt_no_2;
	}

	public void setLt_drwt_no_2(int lt_drwt_no_2) {
		this.lt_drwt_no_2 = lt_drwt_no_2;
	}

	public int getLt_drwt_no_3() {
		return lt_drwt_no_3;
	}

	public void setLt_drwt_no_3(int lt_drwt_no_3) {
		this.lt_drwt_no_3 = lt_drwt_no_3;
	}

	public int getLt_drwt_no_4() {
		return lt_drwt_no_4;
	}

	public void setLt_drwt_no_4(int lt_drwt_no_4) {
		this.lt_drwt_no_4 = lt_drwt_no_4;
	}

	public int getLt_drwt_no_5() {
		return lt_drwt_no_5;
	}

	public void setLt_drwt_no_5(int lt_drwt_no_5) {
		this.lt_drwt_no_5 = lt_drwt_no_5;
	}

	public int getLt_drwt_no_6() {
		return lt_drwt_no_6;
	}

	public void setLt_drwt_no_6(int lt_drwt_no_6) {
		this.lt_drwt_no_6 = lt_drwt_no_6;
	}

	public Long getLt_tot_sell_amnt() {
		return lt_tot_sell_amnt;
	}

	public void setLt_tot_sell_amnt(Long lt_tot_sell_amnt) {
		this.lt_tot_sell_amnt = lt_tot_sell_amnt;
	}

	public Long getLt_first_win_amnt() {
		return lt_first_win_amnt;
	}

	public void setLt_first_win_amnt(Long lt_first_win_amnt) {
		this.lt_first_win_amnt = lt_first_win_amnt;
	}

	public String getLt_drw_date() {
		return lt_drw_date;
	}

	public void setLt_drw_date(String lt_drw_date) {
		this.lt_drw_date = lt_drw_date;
	}


}
