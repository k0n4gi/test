package com.useful.web.websocket;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestWebSocketTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
