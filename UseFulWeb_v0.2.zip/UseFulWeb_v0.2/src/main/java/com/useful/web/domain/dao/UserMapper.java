package com.useful.web.domain.dao;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.useful.web.domain.vo.User;

@Repository
public class UserMapper {
	public void createUser(User user) {
		
	};

	//public User getUserById(String id);

	//public List<User> getUserAll = null;

	//public void updateUser(User user);

	//public void removeUserById(String id);
}
