package com.useful.web.domain.dto;

import com.useful.web.domain.vo.MsgResultVO;

public class ChatDTO extends MsgResultVO{

}
